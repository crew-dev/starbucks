<div class="container">
  <header class="header">
    <div class="header__logo">
      <div class="header__background">
        <a href="#"><img class="starbucks__logo" src="img/svg/logo.svg" alt="logo" /></a>
      </div>
    </div>
    <div class="header__link">
      <a class="link__item" href="#">Главная</a>
      <a class="link__item" href="#">О продукте</a>
      <a class="link__item" href="#">Каталог</a>
    </div>
    <div class="header__cart">
      <a href="#"><img src="img/svg/cart.svg" alt="icon:cart" /></a>
    </div>
  </header>
</div>
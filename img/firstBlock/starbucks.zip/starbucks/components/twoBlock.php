<section class="coffee__inner">
  <div class="container">
    <div class="coffee__wrap">
      <div class="coffee__gallery">
        <a class="coffee__image" href="img/image-1.png" data-fancybox="gallery"
          data-caption="Espresso Cup | Starbucks">
          <img src="img/image-1.png" alt="coffee-1" /></a>
        <a class="coffee__image" href="img/image-2.png" data-fancybox="gallery"
          data-caption="Starbucks House Blend | Small package">
          <img src="img/image-2.png" alt="coffee-2" /></a>
        <a class="coffee__image" href="img/image-3.png" data-fancybox="gallery"
          data-caption="Starbucks House Blend | Big package">
          <img src="img/image-3.png" alt="coffee-3" /></a>
      </div>
      <div class="coffee__info">
        <div class="coffee__title">Мы ценим качество</div>
        <div class="coffee__subtitle">
          Идеальная чашка кофе и вкусная сытная закуска к ней могут
          поднять вам настроение на целый день. Поэтому мы стремимся к
          тому, чтобы все, что вы выбираете, было самого лучшего качества.
        </div>
        <div class="coffee__subtitle">
          Кофе Starbucks house blend - наш качественный продукт который вы
          сможете приготовить у себя дома. Молотые зерна арабики наполнят
          ароматом ваш дом <br> и добавят вкуса в ваш день.
        </div>
      </div>
    </div>
  </div>
  </div>
</section>
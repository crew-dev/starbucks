<section class="coffee__catalog">
  <div class="container">
    <div class="coffee__catalog-title">Выбери свой вкус</div>
    <div class="coffee__cards">
      <div class="coffee__card-item">
        <img src="img/coffee-package-1.png" alt="coffee-package">
        <div class="coffee__card-title">Starbucks <br> house blend</div>
        <div class="coffee__card-price"></div>
        <div class="coffee__card-add"></div>
      </div>
      <div class="coffee__card-item">
        <img src="img/coffee-package-2.png" alt="coffee-package">
        <div class="coffee__card-title">Starbucks house blend brown</div>
        <div class="coffee__card-price"></div>
        <div class="coffee__card-add"></div>
      </div>
      <div class="coffee__card-item">
        <img src="img/coffee-package-3.png" alt="coffee-package">
        <div class="coffee__card-title">Starbucks veranda blend</div>
        <div class="coffee__card-price"></div>
        <div class="coffee__card-add"></div>
      </div>
      <div class="coffee__card-item">
        <img src="img/coffee-package-4.png" alt="coffee-package">
        <div class="coffee__card-title">Starbucks <br> dark espresso</div>
        <div class="coffee__card-price"></div>
        <div class="coffee__card-add"></div>
      </div>
    </div>
  </div>
</section>
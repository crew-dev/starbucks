<main class="hero">
  <div class="hero__info">
    <p class="main__title">КОФЕЙНЫЕ ЗЁРНА</p>
    <h1 class="main__subtitle">STARBUCKS <span class="subtitle__accent">COFFEE BLEND</span></h1>
    <h2 class="main__paragraph">
      Наслаждайся каждой чашечкой ароматного кофе не выходя из дома.
    </h2>
    <button class="main__learn_more">
      Узнать больше
    </button>
  </div>
  <div class="hero__photo"></div>
</main>